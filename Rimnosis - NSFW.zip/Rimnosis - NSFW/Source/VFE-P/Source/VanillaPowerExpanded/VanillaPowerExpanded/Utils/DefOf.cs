﻿using Verse;

namespace GasNetwork
{
    [RimWorld.DefOf]
    public static class DefOf
    {
        public static ThingDef VPE_GasPipe;
        public static ThingDef VPE_GasPipeSub;
        public static SoundDef Explosion_Flame;
    }
}