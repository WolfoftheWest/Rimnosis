﻿using System;
using RimWorld;

namespace VanillaPowerExpanded
{
    public class CompPipeTransmitter : CompPipe
    {
    }
}